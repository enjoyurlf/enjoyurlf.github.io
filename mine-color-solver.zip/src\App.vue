<script setup lang="ts">
import PuzzleWorkbench from './components/PuzzleWorkbench.vue'
</script>

<template>
  <PuzzleWorkbench />
</template>
